import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeSanitize, { defaultSchema } from "rehype-sanitize";
import { Search, ShieldCheck, Menu, X, Copy, Check, Moon, Sun, FileText } from "lucide-react";
import "./styles.css";

const SAFE_SCHEMA = {
  ...defaultSchema,
  tagNames: [
    ...(defaultSchema.tagNames || []),
    "del"
  ],
  attributes: {
    ...defaultSchema.attributes,
    a: ["href", "title", "target", "rel"],
    code: ["className"],
    pre: ["className"]
  },
  protocols: {
    ...defaultSchema.protocols,
    href: ["http", "https", "mailto"]
  }
};

function slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}

function extractStructure(markdown) {
  const lines = markdown.split(/\r?\n/);
  const headings = [];
  let inFence = false;

  for (const line of lines) {
    if (/^\s*```/.test(line)) {
      inFence = !inFence;
      continue;
    }
    if (inFence) continue;

    const match = line.match(/^(#{2,3})\s+(.+?)\s*$/);
    if (!match) continue;

    const level = match[1].length;
    const raw = match[2].replace(/<[^>]*>/g, "").trim();
    if (raw) headings.push({ level, text: raw, id: slugify(raw) });
  }

  return headings;
}

function CodeBlock({ children, className }) {
  const [copied, setCopied] = useState(false);
  const code = String(children).replace(/\n$/, "");
  const language = className?.match(/language-(\w+)/)?.[1] || "text";

  async function copy() {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  return (
    <div className="code-wrap">
      <div className="code-top">
        <span>{language}</span>
        <button onClick={copy} type="button" aria-label="Copy code">
          {copied ? <Check size={14} /> : <Copy size={14} />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre><code>{code}</code></pre>
    </div>
  );
}

function App() {
  const [markdown, setMarkdown] = useState("");
  const [query, setQuery] = useState("");
  const [dark, setDark] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [raw, setRaw] = useState(false);

  useEffect(() => {
    fetch("/test-cases.md")
      .then((r) => r.text())
      .then(setMarkdown)
      .catch(() => setMarkdown("# Unable to load test-cases.md"));
  }, []);

  const headings = useMemo(() => extractStructure(markdown), [markdown]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return headings;
    return headings.filter((h) => h.text.toLowerCase().includes(q));
  }, [headings, query]);

  function jump(id) {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    setMobileOpen(false);
  }

  const components = {
    h2: ({ children }) => {
      const text = String(children);
      return <h2 id={slugify(text)}>{children}</h2>;
    },
    h3: ({ children }) => {
      const text = String(children);
      return <h3 id={slugify(text)}>{children}</h3>;
    },
    pre: ({ children }) => children,
    code: ({ inline, className, children }) =>
      inline ? <code className="inline-code">{children}</code> : <CodeBlock className={className}>{children}</CodeBlock>,
    a: ({ href, children }) => {
      // Links are rendered as links only. Never navigate automatically.
      const safe = /^https?:\/\//i.test(href || "") || /^mailto:/i.test(href || "");
      if (!safe) return <span className="blocked-link">{children}</span>;
      return (
        <a href={href} target="_blank" rel="noopener noreferrer nofollow">
          {children}
        </a>
      );
    },
    img: () => null
  };

  return (
    <div className={dark ? "app dark" : "app light"}>
      <header className="topbar">
        <div className="brand">
          <div className="logo"><ShieldCheck size={20} /></div>
          <div>
            <strong>Security Test Case Library</strong>
            <span>Markdown documentation viewer</span>
          </div>
        </div>

        <div className="top-actions">
          <button className="icon-btn" onClick={() => setDark(!dark)} title="Toggle theme">
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button className="menu-btn" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      <div className="layout">
        <aside className={mobileOpen ? "sidebar open" : "sidebar"}>
          <div className="sidebar-head">
            <div className="search">
              <Search size={16} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search test cases..."
              />
            </div>
          </div>

          <div className="nav-title">DOCUMENTATION</div>
          <nav>
            {filtered.map((h, i) => (
              <button
                key={`${h.id}-${i}`}
                className={`nav-item level-${h.level}`}
                onClick={() => jump(h.id)}
              >
                {h.level === 2 ? <FileText size={14} /> : null}
                <span>{h.text}</span>
              </button>
            ))}
          </nav>
        </aside>

        <main className="content">
          <div className="content-toolbar">
            <div>
              <span className="status-dot" />
              <span>{headings.length} headings indexed</span>
            </div>
            <button className="view-toggle" onClick={() => setRaw(!raw)}>
              {raw ? "Rendered view" : "Raw Markdown"}
            </button>
          </div>

          {raw ? (
            <pre className="raw-markdown">{markdown}</pre>
          ) : (
            <article className="markdown-body">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                rehypePlugins={[[rehypeSanitize, SAFE_SCHEMA]]}
                components={components}
              >
                {markdown}
              </ReactMarkdown>
            </article>
          )}
        </main>
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
